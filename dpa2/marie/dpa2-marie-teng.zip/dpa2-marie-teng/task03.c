#include <assert.h>
#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

void matrix_multiply(const double *A_local, const double *B_local, double *C_local, int local_n)
{
    for (int i = 0; i < local_n; i++)
    {
        for (int j = 0; j < local_n; j++)
        {
            for (int k = 0; k < local_n; k++)
            {
                C_local[i * local_n + j] += A_local[i * local_n + k] * B_local[k * local_n + j];
            }
        }
    }
}

int main()
{
    int rank, size;
    const int n = 5;
    double start_time, end_time;
    double A[5][5] = {
        {1, 0, 0, 0, 0}, {0, 2, 0, 0, 0}, {0, 0, 3, 0, 0}, {0, 0, 0, 4, 0}, {0, 0, 0, 0, 5}};
    double B[5][5] = {
        {1, 0, 0, 0, 0}, {0, 1, 0, 0, 0}, {0, 0, 1, 0, 0}, {0, 0, 0, 1, 0}, {0, 0, 0, 0, 1}};
    double C[5][5] = {};

    MPI_Init(NULL, NULL);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    const int m = n / size;
    const int size_of_last_block = n % size;

    if (rank == 0)
        start_time = MPI_Wtime();
    if (rank < size)
    {
        for (int i = m * rank; i < m * (rank + 1); i++)
        {
            for (int j = 0; j < n; j++)
            {
                C[i][j] = 0;
                for (int k = 0; k < n; k++)
                {
                    C[i][j] += A[i][k] * B[k][j];
                }
            }
        }
    }
    else
    {
        for (int i = m * rank; i < m * rank + size_of_last_block; i++)
        {
            for (int j = 0; j < n; j++)
            {
                C[i][j] = 0;
                for (int k = 0; k < n; k++)
                {
                    C[i][j] += A[i][k] * B[k][j];
                }
            }
        }
    }

    if (rank == 0)
    {
        end_time = MPI_Wtime();
        printf("Time taken for matrix multiplication: %f seconds for %d processors\n",
               end_time - start_time, rank);
    }

    MPI_Finalize();

    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            printf("%f ", C[i][j]);
        }
        printf("\n");
    }
}
